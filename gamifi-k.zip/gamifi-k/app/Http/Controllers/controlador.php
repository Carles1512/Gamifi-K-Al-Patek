<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class controlador extends Controller
{
    public function saveUser(Request $request) {

        $user = new User;

        $user->nick = '';
       


    }
}
